import { MiDirectivaDirective } from './mi-directiva.directive';

describe('MiDirectivaDirective', () => {
  it('should create an instance', () => {
    const directive = new MiDirectivaDirective();
    expect(directive).toBeTruthy();
  });
});
